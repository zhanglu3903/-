# Frp 文档

1.下载文件到服务器和本地主机

2.修改配置文件

```
#本地主机配置
serverAddr = "47.103.39.158"
serverPort = 10023
auth.token = "bmrj@123"

[[proxies]]
name = "ssh"
type = "tcp"
localIP = "127.0.0.1"
localPort = 22
remotePort = 10024
```

```
#远程服务器配置
bindPort = 10023
auth.token = "bmrj@123"
```



3.启动

```
启动远程服务器：./frps -c ./frps.toml。
启动本地客户端：./frpc -c ./frpc.toml。
```

